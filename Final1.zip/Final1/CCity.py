
class City:
    def __init__(self,x,y,nombre):
        self.x=float(x)
        self.y=float(y)
        self.nombre=nombre
    










        
